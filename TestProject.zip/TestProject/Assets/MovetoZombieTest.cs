﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
public class MovetoZombieTest : MonoBehaviour {
    int layerMask = 1 << 8;



    NavMeshAgent agent;

    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
    }

    void Update()
    {
        Debug.Log(agent.remainingDistance);
        if(agent.remainingDistance < 1)
        {
            agent.velocity = Vector3.zero;
            agent.isStopped = true;
        }
        if (Input.GetMouseButtonDown(1))
        {
            RaycastHit hit;

            if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hit, 100, layerMask))
            {
                agent.destination = hit.point;
            }
        }
    }
}
