﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
public class GenerateLevel : NetworkBehaviour {
    public int MapSize = 20;
    public GameObject prefab;
    public GameObject _LeftW;
    public GameObject _RightW;
    public GameObject _TopW;
    public GameObject _Botw;
    public GameObject SpawnLocRed;
    public GameObject SpawnLocBlue;
    public List<GameObject> tiles = new List<GameObject>();
    public void OnPlayerConnected(NetworkPlayer player)
    {
        foreach(GameObject go in tiles)
        {
            Instantiate(go);
            NetworkServer.Spawn(go);
        }
    }
    
    void Start()
    {
        if (isLocalPlayer)
        {
            return;
        }
        int temp = 0;

        for (int c = MapSize / 2; c > -MapSize / 2; c--)
        {

            for (int r = -MapSize / 2; r < MapSize / 2; r++)
            {
                var t = Instantiate(prefab, new Vector3(r, 0, c), Quaternion.identity);
                tiles.Add(t);

                Debug.Log("Col:" + c + " Row:" + r);

                if (Random.Range(0, 3) == 2)
                {
                    t.GetComponent<RAISE>().Run();
                }
                else
                {
                    if (c < 0 - MapSize / 4 && r > 0 + MapSize / 4)
                    {
                       var red= Instantiate(SpawnLocRed, new Vector3(r, 2, c), Quaternion.identity);
                    }
                    if (c > 0 + MapSize / 4 && r < 0 - MapSize / 4)
                    {
                       var blue= Instantiate(SpawnLocBlue, new Vector3(r, 2, c), Quaternion.identity);
                      
                    }
                }
                temp++;

            }
            temp++;
        }
        if (MapSize % 2 == 0)
        {
            GameObject wt = Instantiate(_TopW, new Vector3(-.5f, 0, -MapSize / 2), Quaternion.identity);
            wt.transform.localScale = new Vector3(MapSize, 5, 1);
            GameObject wb = Instantiate(_Botw, new Vector3(-.5f, 0, MapSize / 2+1), Quaternion.identity);
            wb.transform.localScale = new Vector3(MapSize, 5, 1);
            GameObject wl = Instantiate(_LeftW, new Vector3(-MapSize / 2-1, 0, .5f), Quaternion.identity);
            wl.transform.localScale = new Vector3(1, 5, MapSize+2);


            GameObject wr = Instantiate(_RightW, new Vector3(MapSize / 2, 0, .5f), Quaternion.identity);
            wr.transform.localScale = new Vector3(1, 5, MapSize+2);
        }
        else
        {
            GameObject wt = Instantiate(_TopW, new Vector3(-.5f, 0, -MapSize / 2), Quaternion.identity);
            wt.transform.localScale = new Vector3(MapSize-1, 5, 1);
            GameObject wb = Instantiate(_Botw, new Vector3(-.5f, 0, MapSize / 2 + 1), Quaternion.identity);
            wb.transform.localScale = new Vector3(MapSize-1, 5, 1);


            GameObject wl = Instantiate(_LeftW, new Vector3(-MapSize / 2 - 1, 0, .5f), Quaternion.identity);
            wl.transform.localScale = new Vector3(1, 5, MapSize + 1);


            GameObject wr = Instantiate(_RightW, new Vector3(MapSize / 2, 0, .5f), Quaternion.identity);
            wr.transform.localScale = new Vector3(1, 5, MapSize + 1);
        }
        Debug.Log(MapSize % 2);
    }





    // Update is called once per frame
    void Update () {
		
	}
}
