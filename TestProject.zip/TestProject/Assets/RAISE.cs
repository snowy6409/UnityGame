﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RAISE : MonoBehaviour {
    public bool Raised = false;
    public float Growtime;
    public Material Rais;
    public Material Low;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

        if (Raised)
        {
            this.GetComponent<Renderer>().material = Rais;
            if (transform.localScale.y < 5)
                transform.localScale += new Vector3(0, .01f * Growtime, 0);
        }
        else
        {
            this.GetComponent<Renderer>().material = Low;

            if (transform.localScale.y > 1)
                transform.localScale += new Vector3(0, -.01f * Growtime, 0);
        }






    }


   public void Run()
    {
        Raised = !Raised;
    }
}
